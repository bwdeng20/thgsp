%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   "Copyright (c) 2009 The University of Southern California"
%   All rights reserved.
%
%   Permission to use, copy, modify, and distribute this software and its
%   documentation for any purpose, without fee, and without written
%   agreement is hereby granted, provided that the above copyright notice,
%   the following two paragraphs and the author appear in all copies of
%   this software.
%
%   NO REPRESENTATIONS ARE MADE ABOUT THE SUITABILITY OF THE SOFTWARE
%   FOR ANY	PURPOSE. IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED
%   WARRANTY.
%
%   Neither the software developers, the Compression Research Group,
%   or USC, shall be liable for any damages suffered from using this
%   software.
%
%   Author: Sunil K Narang
%   Director: Prof. Antonio Ortega
%   Compression Research Group, University of Southern California
%   http://biron.usc.edu/wiki/index.php?title=CompressionGroup
%   Contact: kumarsun@usc.edu
%
%   Date last modified:	02/01/2012 Sunil K. Narang
%
%   Description:
%   This file generates QMF filter-banks on the 8-connected graph formulation 
%   of 2D digital images as proposed in the paper:
%% "S. K. Narang and Antonio Ortega, "Perfect Reconstruction Two-Channel
%%  Wavelet Filter-Banks For Graph Structured Data",
%  IEEE TSP also avaliable as Tech. Rep. arXiv:1106.3693v3, Dec 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [wav_coeffs] = Biorth_filterbank_demo1(varargin)
clc
close all
len = size(varargin,2);
switch len
    case 0,
        filename = 'lena.png';
        filetype = 'png';
        opt = struct('max_level',4,'vanishing_moments',[7,9],'nnz_factor',1);
    case 2,
        filename = varargin{1};
        filetype = varargin{2};
        opt = struct('max_level',2,'vanishing_moments',[7,9],'nnz_factor',1);
    case 3,
        filename = varargin{1};
        filetype = varargin{2};
        opt = varargin{3};
    otherwise,
        disp('Invalid # of input arguments. Enter inputs as (filename,filetype,option)');
        return;
end

disp('***********Welcome to Demo 1 of Graph-QMF*********')
disp('In this demo we implement a 2-dim separable graph-QMF filterbank on any Image')
addpath Graph_Generators/
addpath Graph_kernels/
addpath sgwt_toolbox/
addpath toolbox/

% Parameters
max_level = opt.max_level; % number of decomposition levels
if isempty(max_level)
    max_level =2;
end
vanishing_moments = opt.vanishing_moments; % filter length
if isempty(vanishing_moments)
    filterlen = [7,9];
end
nnz_factor = opt.nnz_factor; % fraction of non-zero coefficient
if isempty(nnz_factor)
    nnz_factor = 1;%(4^(max_level-2)); 
end
if isempty(filename)
     filename = 'Lichtenstein.png';
     filetype = 'png';
end 
theta = 2; % number of bipartite graphs
Fmax = 2^theta; % Graph Coloring
N = zeros(max_level,1); %size of bipartite graphs at each level
edgemap =1; % uses edge-map if 1, use regular 8-connected graph otherwise
norm_type = 'asym'; % use 'sym'for symmetric Normalized Laplacian matrix
S = sprintf('%s%d%s%d%s%d%s%f%s%d', '# decomposition levels = ', max_level,'.  Biorthtype = ', vanishing_moments(1),' / ',vanishing_moments(2), '.   nnz_factor = ',nnz_factor,'.   Using edgemap = ', edgemap);
disp(S);

%% Section 1: Image Graph Formulation
% Graph Signal
Data = imread(filename,filetype);
if length(size(Data)) == 3
    Data = rgb2gray(Data);
end
Data = double(Data);%/255;
[m n] = size(Data);
m = min([m,n]);
s_im = floor(m/2^max_level)*2^max_level;
% s_im = 10;
Data = Data(1:s_im,1:s_im);
f = Data(:);
f = f/norm(f);

% Graphs
[bptG Colorednodes, beta_dist loc] = image_graphs_multi(Data,max_level,edgemap);  % image graphs


%% Section 2: Filterbank implementation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Normalized Laplacian Matrices for Each Bpt graph
disp('Computing normalized Laplacian matrices for each subgraph...');
Ln_bpt = cell(max_level,theta);
switch norm_type
    case 'sym'
        for level = 1:max_level
            N(level) = length(bptG{level,1});
            for i = 1:theta
                d1 = sum(bptG{level,i},2);
                d1(d1 == 0) = 1; % for isolated nodes
                d1_inv = d1.^(-0.5);
                D1_inv = spdiags(d1_inv, 0, N(level), N(level));
                An = D1_inv*bptG{level,i}*D1_inv;
                An = 0.5*(An + An');
                Ln_bpt{level,i} = speye(N(level)) - An;
            end
        end
    case 'asym'
        for level = 1:max_level
            N(level) = length(bptG{level,1});
            for i = 1:theta
                d1 = sum(bptG{level,i},2);
                d1(d1 == 0) = 1; % for isolated nodes
                d1_inv = d1.^(-1);
                D1_inv = spdiags(d1_inv, 0, N(level), N(level));
                An = D1_inv*(0.5*(bptG{level,i} + bptG{level,i}'));
                Ln_bpt{level,i} = speye(N(level)) - An;
            end
        end
    otherwise
        disp('Unknown normalization option')
        return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% design biorthogonal kernels
Nd = vanishing_moments(1);
Nr = vanishing_moments(2);
% S = sprintf('%s%d%s ' , ' Computing a ',filterlen,' ^th order approximation of Meyer kernel');
% disp(S)
[hi_d,lo_d] = biorth_kernel(Nd,Nr); % Nd zeros for lowpass Nr zeros for highpass
filterlen_hi = length(roots(hi_d));
filterlen_lo = length(roots(lo_d));
h0 = @(x)(polyval(lo_d,x));
h1 = @(x)(polyval(hi_d,x));
g0 = @(x)(polyval(hi_d,2 - x));
g1 = @(x)(polyval(lo_d,2 - x));
arange = [0 2];
c_d{1}=sgwt_cheby_coeff(h0,filterlen_lo,filterlen_lo+1,arange);
c_d{2}=sgwt_cheby_coeff(h1,filterlen_hi,filterlen_hi+1,arange);
c_r{1}=sgwt_cheby_coeff(g0,filterlen_hi,filterlen_hi+1,arange);
c_r{2}=sgwt_cheby_coeff(g1,filterlen_lo,filterlen_lo+1,arange);


%%% Compute filter normalizations
p_lo= conv(lo_d,lo_d);
p_hi = conv(hi_d,hi_d);
p0 = @(x)(polyval(p_lo,x));
p1 = @(x)(polyval(p_hi,x));
c_p{1} = sgwt_cheby_coeff(p0,2*filterlen_lo,2*filterlen_lo+1,arange);
c_p{2} = sgwt_cheby_coeff(p1,2*filterlen_lo,2*filterlen_lo+1,arange);
for level = 1:max_level
    for i = 1:theta
%         tempf_w = speye(N(level));
%         tempP0= sgwt_cheby_op(tempf_w,Ln_bpt{level,i},c_p{i},arange);
%         P0{level,i} = diag(tempP0).^(0.5);
         P0{level,i} = diag(speye(N(level)));
    end
end
% P0(P0 == 0) = 1; % for isolated nodes
% P0 = P0.^(-1);
% P0 = spdiags(P0, 0, N(1), N(1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Filterbank Output at each channel
disp('Computing wavelet transform coefficients ...')
f_w = cell(max_level,1);
Channel_Name = cell(max_level,Fmax);
for level = 1:max_level
    f_w{level} = zeros(N(level)/(2^(level-1)),Fmax);
    for i = 1:Fmax
        if level == 1
            tempf_w = f;
        else
            tempf_w = f_w{level-1}(Colorednodes{level-1,1},1);
        end
        for j = 1: theta
            if beta_dist{level}(i,j) == 1
                tempf_w = sgwt_cheby_op(tempf_w,Ln_bpt{level,j},c_d{1},arange);
                tempf_w = (P0{level,j}.^(-1)).*tempf_w;
                Channel_Name{level,i} = strcat(Channel_Name{level,i},'L');
            else
                tempf_w = sgwt_cheby_op(tempf_w, Ln_bpt{level,j},c_d{2},arange);
                tempf_w = (P0{level,j}.^(-1)).*tempf_w;
                Channel_Name{level,i} = strcat(Channel_Name{level,i},'H');
            end
        end
        f_w{level}(Colorednodes{level,i},i) = tempf_w(Colorednodes{level,i});
    end
end

%% Section 3: Non-linear Approximation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% f_w = find_kbest(f_w, nnz_factor, max_level, Colorednodes); % threshold for nCoeffs best wavelet coefficients

% Plot Wavelet Coeffficents
Data_w = zeros(s_im);
x0 = 0;
y0 = 0;
dim = sqrt(N(max_level))/2;
temp_coeff = zeros(dim*dim,4);
temp_coeff(:,1) = f_w{max_level}(Colorednodes{max_level,1},1);
temp_coeff(:,2) = f_w{max_level}(Colorednodes{max_level,2},2);
temp_coeff(:,3) = f_w{max_level}(Colorednodes{max_level,3},3);
temp_coeff(:,4) = f_w{max_level}(Colorednodes{max_level,4},4);
xind = x0 + (1:dim);
yind = y0 + (1:dim);
% temp_coeff(:,2:4) = abs(temp_coeff(:,2:4));
% temp_coeff(:,1)= temp_coeff(:,1) /norm(temp_coeff(:,1));
Data_w(xind,yind) = reshape(temp_coeff(:,1),dim,dim);
y0 = y0+dim;
xind = x0 + (1:dim);
yind = y0 + (1:dim);
% temp_coeff(:,2)= temp_coeff(:,2) /norm(temp_coeff(:,2));
Data_w(xind,yind) = reshape(temp_coeff(:,2),dim,dim);
x0 = x0+dim;
y0 = 0;
xind = x0 + (1:dim);
yind = y0 + (1:dim);
% temp_coeff(:,3)= temp_coeff(:,3) /norm(temp_coeff(:,3));
Data_w(xind,yind) = reshape(temp_coeff(:,3),dim,dim);
y0 = y0+dim;
xind = x0 + (1:dim);
yind = y0 + (1:dim);
% temp_coeff(:,4)= temp_coeff(:,4) /norm(temp_coeff(:,4));
Data_w(xind,yind) = reshape(temp_coeff(:,4),dim,dim);

for level = (max_level-1):-1:1
    dim = sqrt(N(level))/2;
    temp_coeff = zeros(dim*dim,3);
    temp_coeff(:,1) = f_w{level}(Colorednodes{level,2},2);
    temp_coeff(:,2) = f_w{level}(Colorednodes{level,3},3);
    temp_coeff(:,3) = f_w{level}(Colorednodes{level,4},4);
    %     temp_coeff = abs(temp_coeff);
    x0 = 0;
    y0 = x0 + dim;
    xind = x0 + (1:dim);
    yind = y0 + (1:dim);
    %     temp_coeff(:,1)= temp_coeff(:,1) /norm(temp_coeff(:,1));
    Data_w(xind,yind) = reshape(temp_coeff(:,1),dim,dim);
    x0 = x0 +dim;
    y0 = 0;
    xind = x0 + (1:dim);
    yind = y0 + (1:dim);
    %     temp_coeff(:,2)= temp_coeff(:,2) /norm(temp_coeff(:,2));
    Data_w(xind,yind) = reshape(temp_coeff(:,2),dim,dim);
    y0 = y0 + dim;
    xind = x0 + (1:dim);
    yind = y0 + (1:dim);
    %     temp_coeff(:,3)= temp_coeff(:,3) /norm(temp_coeff(:,3));
    Data_w(xind,yind) = reshape(temp_coeff(:,3),dim,dim);
end
dim = sqrt(N(max_level))/2;
tempw = Data_w;
wav_coeffs = Data_w; % the wavelet coefficients are stored in the image format
tempw(1:dim,1:dim) = 0;
Data_w = Data_w - tempw;
Data_w = rescale(Data_w) + rescale(abs(tempw));
scrsz = get(0,'ScreenSize');
height = scrsz(4)/1.5;
width =  scrsz(3)/2.2;
xinit = 30;
yinit = 30;
figure,
set(gcf,'Position',[xinit,yinit,width,height]);
imshow(uint8(255*Data_w))
title('Wavelet Coefficients')
colormap(gray);

%% Section 4: Reconstruction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reconstruct Signals in Original Graph Domain by using Coefficients
% Compute Filterbank Output at each channel
disp('Reconstructed signals using single channel coefficients ...')
f_hat1 = zeros(N(1),max_level);
for d_level = 1:max_level
    f_hat = f_w;
    for level = d_level: -1 :1
        % Channel_Name = cell(Fmax,1);
        for i = 1:Fmax
            tempf_hat = f_hat{level}(:,i);
            for j = theta: -1: 1
                if beta_dist{level}(i,j) == 1
                    tempf_hat = P0{level,j}.*tempf_hat;
                    tempf_hat = sgwt_cheby_op(tempf_hat,Ln_bpt{level,j},c_r{1},arange);
                else
                    tempf_hat = P0{level,j}.*tempf_hat;
                    tempf_hat = sgwt_cheby_op(tempf_hat,Ln_bpt{level,j},c_r{2},arange);
                end
            end
            f_hat{level}(:,i) = tempf_hat;
        end
                        f_hat{level} = sum(f_hat{level},2);
%         f_hat{level} = f_hat{level}(:,1);
        
        if level >1
            f_hat{level-1}(Colorednodes{level-1,1},1) = f_hat{level};
        end
    end
    f_hat1(:,d_level) = f_hat{level};
end

% Plot reconstructed signals
rowsize = 3;
colsize = ceil(max_level/rowsize)+1;
gap = 0.1;
dr = (1 - (rowsize+1)*gap)/rowsize;
dc = (1 - (colsize+1)*gap)/colsize;
s_im = sqrt(N(1));
xinit = width+30;
yinit = 30;
figure,
set(gcf,'Position',[xinit,yinit,width,height]);
subplot('Position',[gap (1-gap-dc) dr dc])
c_image = reshape(f,s_im,s_im); % original image
imagesc(c_image)
set(gca,'Xtick',[]);
set(gca,'Ytick',[]);
title('Original Image')
for level = 1:max_level
    col = floor((level -1)/rowsize) + 1;
    row = level - (col -1)*rowsize;
    yinit =   1 - (gap+dc)*(col+1);
    xinit = gap + (gap + dr)*(row-1);
    subplot('Position',[xinit yinit dr dc])
    c_image = reshape(f_hat1(:,level),s_im,s_im); % approximation coeffs
    imagesc(c_image)
    set(gca,'Xtick',[]);
    set(gca,'Ytick',[]);
    S1 = repmat('L',1,level);
    S = sprintf('%s%s',' reconstruction from ', S1);
    title(S)
    colormap(gray)
end

%% Section 5: Summary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uLam = 0:1/N:2;

h0 = sgwt_cheby_eval(uLam,c_d{1},arange);
h1 = sgwt_cheby_eval(uLam,c_d{2},arange);
g0 = sgwt_cheby_eval(uLam,c_r{1},arange);
g1 = sgwt_cheby_eval(uLam,c_r{2},arange);
figure,
plot(uLam,h0);
hold on
plot(uLam,h1,'r');
title('Spectral Kernels-Analysis');
legend('Low-pass', 'HighPass');
figure,
plot(uLam,g0);
hold on
plot(uLam,g1,'r');
title('Spectral Kernels-Synthesis');
legend('Low-pass', 'HighPass');
% MSE_kernel = mean((g1-g(uLam)).^2);
Err = 1 - 0.5*(h1.*g1 + h0.*g0);
Err = max(abs(Err));
S = sprintf('%s%f','The max Error in kernel-approximation = ' ,Err);
disp(S);
f1 = repmat(f,1,max_level);
MSE = (f1 - f_hat1).^2;
MSE = sum(MSE);
SNR = 10*log10(norm(f)^2./MSE);
for level = 1:max_level
    S = sprintf('%s%d%s%f','The SNR of reconstruction from level ',level,' = ' ,SNR(level));
    disp(S);
end
end
%% Function for non-linear approximation
function f = find_kbest(f_w, nnz, d_level,Colorednodes)
if nnz < 1
    lin_vec = [];
    for level = 1:d_level
        lin_vec = [lin_vec; f_w{level}(Colorednodes{level,2},2); f_w{level}(Colorednodes{level,3},3); f_w{level}(Colorednodes{level,4},4)];
    end
    nCoeffs = floor(length(lin_vec)*nnz);
    lin_vec = sort(abs(lin_vec(:)),'descend');
    thresh = lin_vec(nCoeffs+1);
    for level = 1:d_level
        temp = f_w{level}(:,2:4);
        temp(abs(temp) <thresh) = 0;
        %     temp(isolated{level},:) = f_w{level}(isolated{level},2:4);
        f_w{level}(:,2:4) = temp;
    end
end
f = f_w;
end