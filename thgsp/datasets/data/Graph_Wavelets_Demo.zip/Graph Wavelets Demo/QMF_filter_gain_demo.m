%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   "Copyright (c) 2009 The University of Southern California"
%   All rights reserved.
%
%   Permission to use, copy, modify, and distribute this software and its
%   documentation for any purpose, without fee, and without written
%   agreement is hereby granted, provided that the above copyright notice,
%   the following two paragraphs and the author appear in all copies of
%   this software.
%
%   NO REPRESENTATIONS ARE MADE ABOUT THE SUITABILITY OF THE SOFTWARE
%   FOR ANY	PURPOSE. IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED
%   WARRANTY.
%
%   Neither the software developers, the Compression Research Group,
%   or USC, shall be liable for any damages suffered from using this
%   software.
%
%   Author: Sunil K Narang
%   Director: Prof. Antonio Ortega
%   Compression Research Group, University of Southern California
%   http://biron.usc.edu/wiki/index.php?title=CompressionGroup
%   Contact: kumarsun@usc.edu
%
%   Date last modified:	07/05/2011 kumarsun
%
%   Description:
%   This file generates QMF filter-banks for arbitrary undirected graphs
%   G = (V,E) proposed in our paper:
%% "S. K. Narang and Antonio Ortega, "Perfect Reconstruction Two-Channel
%%  Wavelet Filter-Banks For Graph Structured Data",
%%  Tech. Rep. arXiv:1106.3693v2, June 2011
%. The code is divided into 7 Sections:
%
%   1. Graph Formulation: To implment our filterbanks, we need an adjacency
%   matrix and an optional 2D location matrix for plotting. The adjacency
%   matrix is a square,symmetric, zeros at diagonal matrix and represents a
%   weighted, undirected graph without self loops. For demonstration, you
%   can  try: line_graph, square_grid, Erdos_random_graph,
%   random_bipartite_graph,
%   and small_world_graph functions placed in the Graph_Generator folder.
%
%   2. Graph Coloring/ Bipartite Subgraph Decomposition: The proposed
%   filterbank operate on bipartite graphs. For arbitrary graphs we
%   proposed a bipartite subgraph decomposition based on Harary[1]
%   algorithm which provides a disjoint collection of bipartite subgraph. A
%   filterbank is implemented on each subgraph leading to a
%   multi-dimensional separable filterbank implementation. Harary's
%   algorithm require proper k-coloring of the graph which is NP-hard
%   problem. Algorithms with various levels of accuracy and speed has been
%   placed in folder Graph_Coloring
%
%   3. Graph-Signal: The filterbanks operate on all scalar functions defined on
%   the vertices of the graph. for demonstration a graph-signal based on
%   eigen-vectors of original graph is generated or can be supplied by user
%
%   4. Filterbank Implementation: The proposed filterbanks are implemented
%   using spectral transforms proposed in Hammond's work[2]. We use a modified
%   Meyer's  wavelet  kernel for the low-pass analysis filter and compute
%   remaining filters by graph-QMF relation proposed in our paper[3]. The
%   exact Meyer filters provide perfect reconstruction with orthogonal
%   basis and are global in spatial domain. A localized polynomial
%   approximation  using Chebychev approximation is used which leads to
%   some reconstruction error and loss of orthogonality. Two modes,
%   'exact','approximate' are provided for demonstration to compare the
%   filterbanks.
%%  Note: It is not recommended to use 'exact' filterbanks on large
%%   graph due to computationally expensive eigen-value decomposition.
%
%   5. Reconstruction: Uses filtered downsampled output coefficients of
%   each channel to reconstruct a signal in original graph-domain.
%
%   6. Summary: Provide MSE and SNR of reconstruction and other statistics
%
%   7. Plots: For arbitrary graphs we use a Delauney triangulation of
%   sampled points  and use sample value of at each node as color of the
%   corresponding edges. For images we use 'imagesc' function of matlab
%
%   Enjoy :)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [wav_coeffs] = QMF_filterbank_Filters_Demo(varargin)
clc
close all
len = 0;%size(varargin,2);
switch len
    case 0,
        filename = 'lena.png';
        filetype = 'png';
        opt = struct('max_level',1  ,'filterlen',24,'nnz_factor',1);
    case 2,
        filename = varargin{1};
        filetype = varargin{2};
        opt = struct('max_level',2,'filterlen',24,'nnz_factor',1);
    case 3,
        filename = varargin{1};
        filetype = varargin{2};
        opt = varargin{3};
    otherwise,
        disp('Invalid # of input arguments. Enter inputs as (filename,filetype,option)');
        return;
end

disp('***********Welcome to Demo 1 of Graph-QMF*********')
disp('In this demo we implement a 2-dim separable graph-QMF filterbank on any Image')
addpath Graph_Generators/
addpath Graph_kernels/
addpath sgwt_toolbox/
addpath toolbox/

% Parameters
max_level = opt.max_level; % number of decomposition levels
if isempty(max_level)
    max_level =2;
end
filterlen = opt.filterlen; % filter length
if isempty(filterlen)
    filterlen = 24;
end
nnz_factor = opt.nnz_factor; % fraction of non-zero coefficient
if isempty(nnz_factor)
    nnz_factor = 1;%(4^(max_level-2));
end
if isempty(filename)
    filename = 'Lichtenstein.png';
    filetype = 'png';
end
filter_type = 'approximate';
theta = 2; % number of bipartite graphs
Fmax = 2^theta; % Graph Coloring
N = zeros(max_level,1); %size of bipartite graphs at each level
edgemap =1; % uses edge-map if 1, use regular 8-connected graph otherwise
norm_type = 'asym'; % use 'sym'for symmetric Normalized Laplacian matrix
S = sprintf('%s%d%s%d%s%f%s%d', '# decomposition levels = ', max_level,'.  FIR approx parameter = ', filterlen, '.   nnz_factor = ',nnz_factor,'.   Using edgemap = ', edgemap);
disp(S);

%% Section 1: Image Graph Formulation
% Graph Signal
Data = imread(filename,filetype);
if length(size(Data)) == 3
    Data = rgb2gray(Data);
end
Data = double(Data);%/255;
[m n] = size(Data);
m = min([m,n]);
s_im = 256;%floor(m/2^max_level)*2^max_level;
% s_im = 10;
Data = Data(1:s_im,1:s_im);
% Data = Data + 150*rand(size(Data));
f = Data(:);
f = f/norm(f);

% Graphs
[bptG Colorednodes, beta_dist loc] = image_graphs_multi(Data,max_level,edgemap);  % image graphs

%% Section 4: Filterbank implementation

disp('Computing normalized Laplacian matrices for each subgraph...');
Ln_bpt = cell(max_level,theta);
switch norm_type
    case 'sym'
        for level = 1:max_level
            N(level) = length(bptG{level,1});
            for i = 1:theta
                d1 = sum(bptG{level,i},2);
                d1(d1 == 0) = 1; % for isolated nodes
                d1_inv = d1.^(-0.5);
                D1_inv = spdiags(d1_inv, 0, N(level), N(level));
                An = D1_inv*bptG{level,i}*D1_inv;
                An = 0.5*(An + An');
                Ln_bpt{level,i} = speye(N(level)) - An;
            end
        end
    case 'asym'
        for level = 1:max_level
            N(level) = length(bptG{level,1});
            for i = 1:theta
                d1 = sum(bptG{level,i},2);
                d1(d1 == 0) = 1; % for isolated nodes
                d1_inv = d1.^(-1);
                D1_inv = spdiags(d1_inv, 0, N(level), N(level));
                An = D1_inv*(0.5*(bptG{level,i} + bptG{level,i}'));
                Ln_bpt{level,i} = speye(N(level)) - An;
            end
        end
    otherwise
        disp('Unknown normalization option')
        return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% design a low-pass kernel
filterlen = 24;
S = sprintf('%s%d%s ' , ' Computing a ',filterlen,' ^th order approximation of Meyer kernel');
disp(S)
%g = @(x)(ideal_kernel(x)); % Ideal Wavelet Kernel
g = @(x)(meyer_kernel(x));  % Meyer Wavelet Kernel
arange = [0 2];
c=sgwt_cheby_coeff(g,filterlen,filterlen+1,arange);
% gain = zeros(N(1),1);
d1 = sum(bptG{level,1},2);
% % d1_inv = d1.^(-1);
poi = find(bptG{1,1}*d1 < 4*d1);
temp_vec = zeros(N(1),1);
temp_vec(poi) = 1;
f = spdiags(temp_vec(:),0,N(1),N(1)); %make it sparse
% d1(d1 == 0) = 1; % for isolated nodes
% f = speye(s_im*s_im);
tempf_w = sgwt_cheby_op(f,Ln_bpt{1},c,arange);
gain = tempf_w.*tempf_w;
gain = sum(gain);
not_poi = setdiff(1:N(1),poi);
gain(not_poi) = 1;
% for i = 1:64
%     for j = 1:64
%         k = (i-1)*64 + j;
%         f = zeros(N(1),1);
%         f(k) = 1;
%         tempf_w = sgwt_cheby_op(f,Ln_bpt{1},c,arange);
%         nbr = find(bptG{1,1}(k,:));
%         nbr = union(k,nbr);
%         temp_gain = norm(tempf_w(nbr));
% % %         tempf_w = tempf_w/sqrt(d1((i-1)*64 + j));
%         tempf_w = tempf_w/temp_gain;
% %         tempf_w = diag(d1.^(0.5))*tempf_w/sqrt(d1(k));
%         % tempf_w = sgwt_cheby_op(tempf_w,Ln_bpt{1},c,arange);
%         gain(k) = norm(tempf_w);
%     end
% end
gain  = reshape(full(gain),s_im,s_im);

imagesc(gain,'XData',1:s_im,'YData',1:s_im);
colorbar


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %         Data = imread('sample1.jpg','jpeg');
% % Data = imread('sample.png','png');
% xy = loc{1};
% figure(1),
% load BWdata
% imagesc(BW1,'XData',1:s_im,'YData',1:s_im);
% colormap(gray)
% for deg = 1:10
%     figure(1),
%     [cj ci] = ginput(1);
%     save coord ci cj
% %     load coord
%     ci = floor(ci)+1;
%     cj = floor(cj)+1;
%     cind = s_im*(cj-1)+ci;
%     n1i = max([1 (ci-filterlen/2)]);
%     n1j = max([1 (cj-filterlen/2)]);
%     n2i = min([s_im (ci+filterlen/2)]);
%     n2j = min([s_im (cj+filterlen/2)]);
%     jcord = n1j:n2j;
%     icord = n1i:n2i;
%     nind = [];
%     for iii = 1:length(jcord)
%         nind = [nind s_im*(jcord(iii)-1)+icord];
%     end
%     Atemp = bptG{1}+bptG{2};
%     Atemp = full(Atemp(nind,nind));
%     xytemp = xy(nind,:);
%      figure(2),
%     imagesc(Data(n1i:n2i,n1j:n2j),'XData',n1i:n2i,'YData',n1j:n2j);
%     title('Image')
%     tempf_w = 0*f;
%     tempf_w(cind) = 1; % delta function at cind
%     tempf_w = sgwt_cheby_op(tempf_w,Ln_bpt{1},c,arange);
%     f_w = sgwt_cheby_op(tempf_w,Ln_bpt{2},c,arange);
%     f_w = f_w/f_w(cind);
%     f_w = f_w.*f_w;
%     f_w = 10*log10(f_w+10^-10);
%     f_w(f_w < -50) = -50;
%     f_w = reshape(f_w',s_im,s_im);
%     figure(3),
%     temp = BW1(ci,cj);
%     BW1(ci,cj) = 0.5;
%     imagesc(BW1(n1i:n2i,n1j:n2j),'XData',n1i:n2i,'YData',n1j:n2j);
%      xrange = get(gca,'xlim');
%     yrange = get(gca,'ylim');
%     BW1(ci,cj) = temp;
%     title('Original Edge Information')
%     %             colormap(gray)
%     figure(4),
%     wgPlot(Atemp,xytemp);
%     title('Graph-Formulation')
% %     set(gca,'xlim',xrange);
% %     set(gca,'ylim',yrange);
% %     axis([min(xytemp(:,1)) max(xytemp(:,1)) min(xytemp(:,2)) max(xytemp(:,2))])
%     set(gca,'ydir','reverse')
% %     set(gca,'xlim',xrange);
% %     set(gca,'ylim',yrange);
%    
%     
%     figure(5)
% %     imagesc(f_w(n1i:n2i,n1j:n2j),'XData',n1i:n2i,'YData',n1j:n2j);
%     surf(n1i:n2i,n1j:n2j,f_w(n1i:n2i,n1j:n2j))
%     view(0,90)
% %     show_wavelet(f_w(nind),xytemp(:,1),xytemp(:,2));
%     title('High-pass filterbank for a node')
%     set(gca,'xlim',xrange);
%     set(gca,'ylim',yrange,'ydir','reverse');
%     
%     colorbar;
%     
%     
%     tempf_w = Data;%(n1i:n2i,n1j:n2j);
%     tempf_w = tempf_w(:); % delta function at cind
%     tempf_w = sgwt_cheby_op(tempf_w,Ln_bpt{1},c,arange);
%     f_w = sgwt_cheby_op(tempf_w,Ln_bpt{2},c,arange);
% %     f_w = f_w/f_w(cind);
%     f_w = abs(f_w);%.*f_w;
% %     f_w = 10*log10(f_w+10^-10);
% %     f_w(f_w < -50) = -50;
%     f_w = reshape(f_w',s_im,s_im);
%     figure(6)
%     imagesc(f_w(n1i:n2i,n1j:n2j),'XData',n1i:n2i,'YData',n1j:n2j);
% %     surf(n1i:n2i,n1j:n2j,f_w(n1i:n2i,n1j:n2j))
% %     view(0,90)
% %     show_wavelet(f_w(nind),xytemp(:,1),xytemp(:,2));
%     title('undecimated HH band coefficients')
%     colormap(gray)
%     set(gca,'xlim',xrange);
%     set(gca,'ylim',yrange);
%     colorbar;
% 
% %     figure(5)
% %     imagesc(Data(n1i:n2i,n1j:n2j),'XData',n1i:n2i,'YData',n1j:n2j);
% %     title('Original Image')
%     %             colormap(gray)
% %     f_w = sgwt_cheby_op(tempf_w,2*speye(N) - Ln_bpt{1},c,arange);
% %     f_w = f_w.*f_w;
% %     f_w = f_w/norm(f_w);
% %     f_w = 10*log10(f_w+10^-10);
% %     f_w(f_w < -50) = -50;
% %     f_w = reshape(f_w',s_im,s_im);
% %     figure(5),
% %     imagesc(f_w(n1i:n2i,n1j:n2j),'XData',n1i:n2i,'YData',n1j:n2j);
% %     title('High-pass filterbank for a node')
%     %             colormap(gray)
% end
