%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   "Copyright (c) 2009 The University of Southern California"
%   All rights reserved.
%
%   Permission to use, copy, modify, and distribute this software and its
%   documentation for any purpose, without fee, and without written
%   agreement is hereby granted, provided that the above copyright notice,
%   the following two paragraphs and the author appear in all copies of
%   this software.
%
%   NO REPRESENTATIONS ARE MADE ABOUT THE SUITABILITY OF THE SOFTWARE
%   FOR ANY	PURPOSE. IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED
%   WARRANTY.
%
%   Neither the software developers, the Compression Research Group,
%   or USC, shall be liable for any damages suffered from using this
%   software.
%
%   Author: Sunil K Narang
%   Director: Prof. Antonio Ortega
%   Compression Research Group, University of Southern California
%   http://biron.usc.edu/wiki/index.php?title=CompressionGroup
%   Contact: kumarsun@usc.edu
%
%   Date last modified:	02/01/2012 Sunil K. Narang
%
%   Description:
%   This file generates QMF filter-banks on the 8-connected graph formulation
%   of 2D digital images as proposed in the paper:
%% "S. K. Narang and Antonio Ortega, "Perfect Reconstruction Two-Channel
%%  Wavelet Filter-Banks For Graph Structured Data",
%  IEEE TSP also avaliable as Tech. Rep. arXiv:1106.3693v3, Dec 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear
close all
len = 0;
switch len
    case 0,
        filename = 'lena.png';
        filetype = 'png';
        opt = struct('max_level',4,'vanishing_moments',[11,13],'nnz_factor',1,'edgemap',1);
    case 2,
        filename = varargin{1};
        filetype = varargin{2};
        opt = struct('max_level',2,'vanishing_moments',[7,9],'nnz_factor',1,'edgemap',0);
    case 3,
        filename = varargin{1};
        filetype = varargin{2};
        opt = varargin{3};
    otherwise,
        disp('Invalid # of input arguments. Enter inputs as (filename,filetype,option)');
        return;
end

disp('***********Welcome to Demo 1 of Graph-QMF*********')
disp('In this demo we implement a 2-dim separable graph-QMF filterbank on any Image')
addpath Graph_Generators/
addpath Graph_kernels/
addpath sgwt_toolbox/
addpath toolbox/
addpath ImageQualityMeasures

% Parameters
max_level = opt.max_level; % number of decomposition levels
if isempty(max_level)
    max_level =2;
end
vanishing_moments = opt.vanishing_moments; % filter length
if isempty(vanishing_moments)
    filterlen = [7,9];
end
nnz_factor = opt.nnz_factor; % fraction of non-zero coefficient
if isempty(nnz_factor)
    nnz_factor = 1;%(4^(max_level-2));
end
if isempty(filename)
    filename = 'Lichtenstein.png';
    filetype = 'png';
end
edgemap = opt.edgemap;
if isempty(edgemap)
    edgemap =0; % uses edge-map if 1, use regular 8-connected graph otherwise
end
theta = 2; % number of bipartite graphs
Fmax = 2^theta; % Graph Coloring
N = zeros(max_level,1); %size of bipartite graphs at each level

norm_type = 'asym'; % use 'sym'for symmetric Normalized Laplacian matrix
S = sprintf('%s%d%s%d%s%d%s%f%s%d', '# decomposition levels = ', max_level,'.  Biorthtype = ', vanishing_moments(1),' / ',vanishing_moments(2), '.   nnz_factor = ',nnz_factor,'.   Using edgemap = ', edgemap);
disp(S);

%% Section 1: Image Graph Formulation
% Graph Signal
Data = imread(filename,filetype);
if length(size(Data)) == 3
    Data = rgb2gray(Data);
end
Data = double(Data);%/255;
[m n] = size(Data);
m = min([m,n]);
s_im = floor(m/2^max_level)*2^max_level;
% s_im = 10;
Data = Data(1:s_im,1:s_im);
f = Data(:);
f = f/255;

% Graphs
[bptG Colorednodes, beta_dist loc] = image_graphs_multi(Data,max_level,edgemap);  % image graphs


%% Section 2: Filterbank implementation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Normalized Laplacian Matrices for Each Bpt graph
disp('Computing normalized Laplacian matrices for each subgraph...');
Ln_bpt = cell(max_level,theta);
switch norm_type
    case 'sym'
        for level = 1:max_level
            N(level) = length(bptG{level,1});
            for i = 1:theta
                d1 = sum(bptG{level,i},2);
                d1(d1 == 0) = 1; % for isolated nodes
                d1_inv = d1.^(-0.5);
                D1_inv = spdiags(d1_inv, 0, N(level), N(level));
                An = D1_inv*bptG{level,i}*D1_inv;
                An = 0.5*(An + An');
                Ln_bpt{level,i} = speye(N(level)) - An;
            end
        end
    case 'asym'
        for level = 1:max_level
            N(level) = length(bptG{level,1});
            for i = 1:theta
                d1 = sum(bptG{level,i},2);
                d1(d1 == 0) = 1; % for isolated nodes
                d1_inv = d1.^(-1);
                D1_inv = spdiags(d1_inv, 0, N(level), N(level));
                An = D1_inv*(0.5*(bptG{level,i} + bptG{level,i}'));
                Ln_bpt{level,i} = speye(N(level)) - An;
            end
        end
    otherwise
        disp('Unknown normalization option')
        return;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% design biorthogonal kernels
Nd = vanishing_moments(1);
Nr = vanishing_moments(2);
% S = sprintf('%s%d%s ' , ' Computing a ',filterlen,' ^th order approximation of Meyer kernel');
% disp(S)
[hi_d,lo_d] = biorth_kernel(Nd,Nr); % Nd zeros for lowpass Nr zeros for highpass
filterlen_lo = length(roots(lo_d));
filterlen_hi = length(roots(hi_d));
h0 = @(x)(polyval(lo_d,x));
h1 = @(x)(polyval(hi_d,x));
g0 = @(x)(polyval(hi_d,2 - x));
g1 = @(x)(polyval(lo_d,2 - x));
arange = [0 2];
c_d{1}=sgwt_cheby_coeff(h0,filterlen_lo,filterlen_lo+1,arange);
c_d{2}=sgwt_cheby_coeff(h1,filterlen_hi,filterlen_hi+1,arange);
c_r{1}=sgwt_cheby_coeff(g0,filterlen_hi,filterlen_hi+1,arange);
c_r{2}=sgwt_cheby_coeff(g1,filterlen_lo,filterlen_lo+1,arange);


%%% Compute filter normalizations
p_lo= conv(lo_d,lo_d);
p_hi = conv(hi_d,hi_d);
p0 = @(x)(polyval(p_lo,x));
p1 = @(x)(polyval(p_hi,x));
c_p{1} = sgwt_cheby_coeff(p0,2*filterlen_lo,2*filterlen_lo+1,arange);
c_p{2} = sgwt_cheby_coeff(p1,2*filterlen_lo,2*filterlen_lo+1,arange);
for level = 1:max_level
    for i = 1:theta
%         tempf_w = speye(N(level));
%         tempP0= sgwt_cheby_op(tempf_w,Ln_bpt{level,i},c_p{i},arange);
%         P0{level,i} = diag(tempP0).^(0.5);
        P0{level,i} = diag(speye(N(level)));
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Filterbank Output at each channel
disp('Computing wavelet transform coefficients ...')
f_w = cell(max_level,1);
Channel_Name = cell(max_level,Fmax);
for level = 1:max_level
    f_w{level} = zeros(N(level)/(2^(level-1)),Fmax);
    for i = 1:Fmax
        if level == 1
            tempf_w = f;
        else
            tempf_w = f_w{level-1}(Colorednodes{level-1,1},1);
        end
        for j = 1: theta
            if beta_dist{level}(i,j) == 1
                tempf_w = sgwt_cheby_op(tempf_w,Ln_bpt{level,j},c_d{1},arange);
                tempf_w = (P0{level,j}.^(-1)).*tempf_w;
                Channel_Name{level,i} = strcat(Channel_Name{level,i},'L');
            else
                tempf_w = sgwt_cheby_op(tempf_w, Ln_bpt{level,j},c_d{2},arange);
                tempf_w = (P0{level,j}.^(-1)).*tempf_w;
                Channel_Name{level,i} = strcat(Channel_Name{level,i},'H');
            end
        end
        f_w{level}(Colorednodes{level,i},i) = tempf_w(Colorednodes{level,i});
    end
end


%% Section 3: Non-linear Approximation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Section 3: Non-linear Approximation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Bio_Scale] = Biorth_filterbank_scaling_factor(filename,filetype,opt);
% load Bio_Scale_mat
f_w1 = f_w;
% f_w2 = f_w1;
% for level = 1:max_level
%     for F = 1:Fmax
%         f_w2{level}(:,F) = f_w2{level}(:,F)/Bio_Scale(level,F);
%     end
% end
wav_coeffs = wavelet_ordering(f_w1,s_im, Colorednodes);
% 
% figure,imagesc(wav_coeffs);
% colormap(gray);
% title('Original wav coeffs');
origImg = 255*reshape(f,s_im,s_im);
nnz = 0:0.01:0.16;
MSE = zeros(1,length(nnz));
SSIM = zeros(1,length(nnz));
PSNR = zeros(1,length(nnz));
SNR = zeros(1,length(nnz));
for iter = 1:length(nnz)
    nnz_factor = nnz(iter);
%         f_w = find_kbest(f_w1, nnz_factor, max_level, Colorednodes); % threshold for nCoeffs best wavelet coefficients
    %     wav_coeffs = wavelet_ordering(f_w,s_im, Colorednodes);
    %     figure,imagesc(wav_coeffs);
    %     colormap(gray);
    %     title('without scaling')
    
    [f_w thresh(iter)] = find_kbest_biorth(f_w1, nnz_factor, max_level, Colorednodes, Bio_Scale); % threshold for nCoeffs best wavelet coefficients
%     for level = 1:max_level
%         f_w{level} = f_w1{level}-f_w{level};
%     end
%     f_w2 = f_w;
%     for level = 1:max_level
%         for F = 1:Fmax
%             f_w2{level}(:,F) = f_w2{level}(:,F)/Bio_Scale(level,F);
%         end
%     end
%     wav_coeffs = wavelet_ordering(f_w2,s_im, Colorednodes);
%     if iter == 1
%         cLim = [min(wav_coeffs(:)), max(wav_coeffs(:))];
%     end
%     figure,imagesc(wav_coeffs);
%     colormap(gray);
%     colorbar
    %     title('with scaling')
    
    %% Section 4: Reconstruction
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Reconstruct Signals in Original Graph Domain by using Coefficients
    % Compute Filterbank Output at each channel
    disp('Reconstructed signals using single channel coefficients ...')
    f_hat1 = zeros(N(1),1);
    for d_level = max_level
        f_hat = f_w;
        for level = d_level: -1 :1
            % Channel_Name = cell(Fmax,1);
            for i = 1:Fmax
                tempf_hat = f_hat{level}(:,i);
                for j = theta: -1: 1
                    if beta_dist{level}(i,j) == 1
                        tempf_hat = P0{level,j}.*tempf_hat;
                        tempf_hat = sgwt_cheby_op(tempf_hat,Ln_bpt{level,j},c_r{1},arange);
                    else
                        tempf_hat = P0{level,j}.*tempf_hat;
                        tempf_hat = sgwt_cheby_op(tempf_hat,Ln_bpt{level,j},c_r{2},arange);
                    end
                end
                f_hat{level}(:,i) = tempf_hat;
            end
            f_hat{level} = sum(f_hat{level},2);
            %         f_hat{level} = f_hat{level}(:,1);
            
            if level >1
                f_hat{level-1}(Colorednodes{level-1,1},1) = f_hat{level};
            end
        end
        f_hat1= f_hat{level};
    end
    
    
    %% Section 5: Summary
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    distImg = 255*reshape(f_hat1,s_im,s_im);
        figure,imagesc(abs(distImg));
        colormap(gray)
        colorbar
    %     Mean Square Error
    MSE(iter) = MeanSquareError(origImg, distImg);
    % disp('Mean Square Error = ');
    % disp(MSE);
    
    %Peak Signal to Noise Ratio
    PSNR(iter) = PeakSignaltoNoiseRatio(origImg, distImg);
    % disp('Peak Signal to Noise Ratio = ');
    % disp(PSNR);
    
    SSIM(iter) = ssim(origImg,distImg);
    
    SE = (f - f_hat1).^2;
    SE = sum(SE);
    if(SE > 0)
        SNR(iter) = 10*log(norm(f)^2./SE)/log(10);
    else
        SNR(iter) = 99;
    end
end
