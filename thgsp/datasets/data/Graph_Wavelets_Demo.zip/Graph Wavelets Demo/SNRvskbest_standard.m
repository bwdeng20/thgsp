% function [] = Standard_filterbank_Demo_Images_multi_kbest(varargin)
clc
clear
close all
len = 0;

filename = 'Lichtenstein.png';
filetype = 'png';

% filename = 'cornellbox.jpg';
% filetype = 'jpeg';

% edgemap = 1;
% else
%     filename = varargin(1);
%     filetype = varargin(2);
%
% end
disp('***********Welcome to Demo 1 of Graph-QMF*********')
disp('In this demo we implement a standard 2-dim separable filterbank on any Image')
max_level = 4;


%% Graph Signal
Data = imread(filename,filetype);
if length(size(Data)) == 3
    Data = rgb2gray(Data);
end
Data = double(Data);%/255;
[m n] = size(Data);
m = min([m,n]);
s_im = floor(m/2^max_level)*2^max_level;
% s_im = 512;
% s_im = 10;
Data = Data(1:s_im,1:s_im);
% Data = Data/norm(Data(:));

% dim = s_im/2^max_level;
% tempw = Data_w;
% tempw(1:dim,1:dim) = 0;
% Data_w = Data_w - tempw;
% Data_w = rescale(Data_w) + rescale(abs(100*tempw));
% % % for level = 1:max_level
% % %     Data_w(s_im/2^level,1:s_im/2^(level+1)) = 'r';
% % %     Data_w(1:s_im/2^(level+1),s_im/2^level) = 'r';
% % % end
% figure,
% imshow(uint8(255*Data_w))
% colormap(gray);
% 
% energy = zeros(max_level,4);
% for level = 1:max_level
%     x0 = 0;
%     y0 = 0;
%     dim = s_im/2^level;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,1) = norm(tempw(:)).^2; 
%     y0 = y0+dim;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,2) = norm(tempw(:)).^2;
%     x0 = x0+dim;
%     y0 = 0;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,3) = norm(tempw(:)).^2;
%     y0 = y0+dim;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,4) = norm(tempw(:)).^2;
% end

Data_w1 = wavecdf97(Data,max_level);    
origImg = Data;
f = Data(:);
nnz = 0.01;%0.01:0.01:0.16;
MSE = zeros(1,length(nnz));
SSIM = zeros(1,length(nnz));
PSNR = zeros(1,length(nnz));
SNR = zeros(1,length(nnz));
for iter = 1:length(nnz)
    nnz_factor = nnz(iter);
    Data_w = Data_w1;
    % save ballet_image_CDF97 Data_w
    temp_w = Data_w;
    len = s_im/2^max_level;
    temp_w(1:len,1:len) = 0;
    coeffs = temp_w(:);
    thresh = sort(abs(coeffs),'descend');
%     nCoeffs = nnz_factor -1;
    nCoeffs = s_im^2 - len^2;
    nCoeffs = floor(nCoeffs*nnz_factor);
    if nnz_factor ==0
        coeffs = 0*coeffs;
    else
        thresh = thresh(nCoeffs+1);
        coeffs(abs(coeffs) <thresh) = 0;
    end
    temp_w = reshape(coeffs,s_im,s_im);
    temp_w(1:len,1:len) = Data_w(1:len,1:len);
    Data_w = temp_w;
    Data_hat = wavecdf97(Data_w,-max_level);
    distImg = Data_hat;
    f_hat1 = distImg(:);
    MSE(iter) = MeanSquareError(origImg, distImg);
    % disp('Mean Square Error = ');
    % disp(MSE);
    
    %Peak Signal to Noise Ratio
    PSNR(iter) = PeakSignaltoNoiseRatio(origImg, distImg);
    % disp('Peak Signal to Noise Ratio = ');
    % disp(PSNR);
    
    SSIM(iter) = ssim(origImg,distImg);
    MSE1 = (f - f_hat1).^2;
    MSE1 = sum(MSE1);
    SNR(iter) = 10*log10(norm(f)^2./MSE1);
end
