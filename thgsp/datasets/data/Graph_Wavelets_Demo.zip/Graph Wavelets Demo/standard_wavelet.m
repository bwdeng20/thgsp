% function [] = Standard_filterbank_Demo_Images_multi_kbest(varargin)
clear
clc
close all
% if size(varargin,2) == 0
filename = 'Lichtenstein.png';
filetype = 'png';
% filename = 'cornellbox.jpg';
% filetype = 'jpeg';

% edgemap = 1;
% else
%     filename = varargin(1);
%     filetype = varargin(2);
%
% end
disp('***********Welcome to Demo 1 of Graph-QMF*********')
disp('In this demo we implement a standard 2-dim separable filterbank on any Image')
max_level = 1;


%% Graph Signal
Data = imread(filename,filetype);
if length(size(Data)) == 3
    Data = rgb2gray(Data);
end
Data = double(Data);%/255;
[m n] = size(Data);
m = min([m,n]);
s_im = floor(m/2^max_level)*2^max_level;
% s_im = 512;
% s_im = 10;
Data = Data(1:s_im,1:s_im);
Data = Data/norm(Data(:));
nnz_factor = 1/100;

%% Section 1: Design Filters
% filter_file = '/home/kumarsun/Dropbox/Graph-QMF-toolbox/Graph_kernels/QMF/QMF_24B.cof';
% [h, den] = ReadFilter (filter_file);
% [h0,h1,g0,g1] = orthfilt(h);
% 
% %% Section 2: 2D wavelet transform
% dwtmode('per');
% [coeffs,S] = wavedec2(Data,max_level,'bior9.7');
% thresh = sort(abs(coeffs),'descend');
% thresh = thresh(nCoeffs+1);
% coeffs(coeffs <thresh) = 0;
% 
% Data_w = zeros(s_im);
% x0 = 0;
% y0 = 0;
% dim = S(2,1);
% temp_coeff = coeffs(1:(dim*dim*4));
% temp_coeff = reshape(temp_coeff,dim*dim,4);
% xind = x0 + (1:dim);
% yind = y0 + (1:dim);
% Data_w(xind,yind) = reshape(temp_coeff(:,1),dim,dim);
% y0 = y0+dim;
% xind = x0 + (1:dim);
% yind = y0 + (1:dim);
% Data_w(xind,yind) = reshape(temp_coeff(:,2),dim,dim);
% x0 = x0+dim;
% y0 = 0;
% xind = x0 + (1:dim);
% yind = y0 + (1:dim);
% Data_w(xind,yind) = reshape(temp_coeff(:,3),dim,dim);
% y0 = y0+dim;
% xind = x0 + (1:dim);
% yind = y0 + (1:dim);
% Data_w(xind,yind) = reshape(temp_coeff(:,4),dim,dim);
% 
% for level = 2:max_level
%     dim = S(level+1,1);
%     bias = S(level,1)*S(level,1)*4+1;
%     temp_coeff = coeffs(bias:(bias+ dim*dim*3 -1));
%     temp_coeff = reshape(temp_coeff,dim*dim,3);
%     x0 = 0;
%     y0 = x0 + dim;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     Data_w(xind,yind) = reshape(temp_coeff(:,1),dim,dim);
%     x0 = x0 +dim;
%     y0 = 0;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     Data_w(xind,yind) = reshape(temp_coeff(:,2),dim,dim);
%     y0 = y0 + dim;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     Data_w(xind,yind) = reshape(temp_coeff(:,3),dim,dim);
% end
% save cornellbox_image_johnston Data_w
Data_w = wavecdf97(Data,max_level);
% dim = s_im/2^max_level;
% tempw = Data_w;
% tempw(1:dim,1:dim) = 0;
% Data_w = Data_w - tempw;
% Data_w = rescale(Data_w) + rescale(abs(100*tempw));
% % % for level = 1:max_level
% % %     Data_w(s_im/2^level,1:s_im/2^(level+1)) = 'r';
% % %     Data_w(1:s_im/2^(level+1),s_im/2^level) = 'r';
% % % end
% figure,
% imshow(uint8(255*Data_w))
% colormap(gray);
% 
% energy = zeros(max_level,4);
% for level = 1:max_level
%     x0 = 0;
%     y0 = 0;
%     dim = s_im/2^level;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,1) = norm(tempw(:)).^2; 
%     y0 = y0+dim;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,2) = norm(tempw(:)).^2;
%     x0 = x0+dim;
%     y0 = 0;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,3) = norm(tempw(:)).^2;
%     y0 = y0+dim;
%     xind = x0 + (1:dim);
%     yind = y0 + (1:dim);
%     tempw = Data_w(xind,yind);
%     energy(level,4) = norm(tempw(:)).^2;
% end

    
    
% save ballet_image_CDF97 Data_w
temp_w = Data_w;
len = s_im/2^max_level;
temp_w(1:len,1:len) = 0;
coeffs = temp_w(:);
thresh = sort(abs(coeffs),'descend');
nCoeffs = s_im^2 - len^2;
nCoeffs = floor(nCoeffs*nnz_factor);
thresh = thresh(nCoeffs+1);
coeffs(coeffs <thresh) = 0;
temp_w = reshape(coeffs,s_im,s_im);
temp_w(1:len,1:len) = Data_w(1:len,1:len);
Data_w = temp_w;
% figure,
% imagesc(log(Data_w.^2+10^-10))
colormap(gray);
Data_hat = wavecdf97(Data_w,-max_level);
MSE = (Data(:) - Data_hat(:)).^2;
MSE = sum(MSE);
SNR = 10*log10(norm(Data(:))^2./MSE);
figure,
subplot(2,1,1)
imagesc(Data);
subplot(2,1,2)
imagesc(Data_hat);
colormap(gray)
c_image = Data_hat;
% save cornellbox1_reconst_image_johnston c_image
save ballet1_reconst_image_CDF97 c_image