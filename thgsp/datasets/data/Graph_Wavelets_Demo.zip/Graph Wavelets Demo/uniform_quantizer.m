function f_w1 = uniform_quantizer(f_w,bitrate)
% uniform quantizer
lin_vec = [];
max_level = length(f_w1);
for level = 1:max_level
    lin_vec = [lin_vec; sum(f_w{level}(:,2:4))];
end
mM = [min(lin_vec), max(lin_vec)];
