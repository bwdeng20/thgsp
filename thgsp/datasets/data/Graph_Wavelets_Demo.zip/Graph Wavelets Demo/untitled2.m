load CDF97_
figure(1),
subplot(1,2,1)
plot(nnz,PSNR,'*-');
title('PSNR Comparison');
xlabel('fraction of non-zero detail coefficients');
ylabel('PSNR(dB)')
hold on
figure(1),
subplot(1,2,2)
plot(nnz,SSIM,'*-');
hold on
title('Structure Similarity Comparison');
xlabel('fraction of non-zero detail coefficients');
ylabel('SSIM')

load gQMF_withoutedge
figure(1),
subplot(1,2,1)
plot(nnz,PSNR,'mo-');
figure(1),
subplot(1,2,2)
plot(nnz,SSIM,'mo-');

load gQMF_withedge
figure(1),
subplot(1,2,1)
plot(nnz,PSNR,'gs-');
legend('std CDF9/7', 'unweighted gQMF', 'weighted gQMF');
figure(1),
subplot(1,2,2)
plot(nnz,SSIM,'gs-');
legend('std CDF9/7', 'unweighted gQMF', 'weighted gQMF');


% load Biorth_withoutedge
% figure(1),
% subplot(1,2,1)
% plot(nnz,PSNR,'k^-');
% figure(1),
% subplot(1,2,2)
% plot(nnz,SSIM,'k^-');
% 
% load Biorth_withedge
% figure(1),
% subplot(1,2,1)
% plot(nnz,PSNR,'rp-');
% legend('std CDF9/7', 'unweighted gQMF', 'weighted gQMF', 'unweighted gBior', 'weighted gBior');
% figure(1),
% subplot(1,2,2)
% plot(nnz,SSIM,'rp-');
% legend('std CDF9/7', 'unweighted gQMF', 'weighted gQMF', 'unweighted gBior', 'weighted gBior');
